        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="index.php">Dashboard</a> 
          </li>
          <li class="breadcrumb-item active"><?php echo $current_page; ?></li>
        </ol>
        <?php $current_page=""; ?>