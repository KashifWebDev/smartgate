<?php 
  class Database {
    // DB Params
    private $host = 'localhost';
    private $db_name = 'accesson_db_smart';
    private $username = 'accesson_smart';
    private $password = 'bYSaw9LI2Lpw';
    private $conn;

    // DB Connect
    public function connect() {
      $this->conn = null;

      try { 
        $this->conn = new PDO('mysql:host=' . $this->host . ';dbname=' . $this->db_name, $this->username, $this->password);
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      } catch(PDOException $e) {
        echo 'Connection Error: ' . $e->getMessage();
      }

      return $this->conn;
    }
  }



  ?>