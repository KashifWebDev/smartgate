<?php
require '../parts/startup.php';
$dir="../";
?>
    <!DOCTYPE html>
    <html lang="en">

<?php require '../parts/head.php'; ?>

<body id="page-top">
<?php require '../parts/top-nav.php'; ?>

<div id="wrapper">

    <!-- Sidebar -->
<?php require 'left-navbar.php'; ?>

    <div id="content-wrapper">

        <div class="container-fluid">

            <!-- Breadcrumbs-->
<?php require '../parts/top-pagger.php'; ?>