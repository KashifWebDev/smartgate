<?php
$dir =""; // $dir = "../";
//$path = "http://localhost/smartgate/";
$path = "http://access1technologies.com/smartgate/";
error_reporting(0);

?>