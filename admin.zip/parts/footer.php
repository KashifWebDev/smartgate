﻿      <!-- Sticky Footer -->
      <footer class="sticky-footer" style="width: 100%;position: inherit;padding-left: 30%;">
        <div class="center" style="display: contents;">
        	<img style="width: 150px;" src="<?php echo $dir; ?>images/logo.jpg">
          <div class="copyright text-center my-auto" id="footer-text">
            <span>Copyright © MyGate ~ 2020</span>
          </div>
        </div>
      </footer>