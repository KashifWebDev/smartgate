<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  require '../parts/db.php';

  $data = json_decode(file_get_contents("php://input"));

  if(isset($data->Machine_MAC) && isset($data->Action))
{
    $Machine_Mac = $data->Machine_MAC;
    $Action = $data->Action;
    $sql = "SELECT * FROM user_and_devices WHERE machine_mac='".$Machine_Mac."'";
    $result = mysqli_query($con, $sql);
    $data = mysqli_fetch_array($result);
    $count=mysqli_num_rows($result);

    if($data["relay"]=="None"){
        $post_arr = array(
            'Response' => 'NACK',
            'Message' => 'Relay is set to None. No Open/Hold/Close requests will be performed.'
        );
        print_r(json_encode($post_arr));
        die();exit();
    }
    
     $a = "SELECT * FROM users WHERE id=".$data["user_id"];
     //echo $a;
     $b = mysqli_query($con, $a);
     $c = mysqli_fetch_assoc($b);
     //print_r($c);
     if(mysqli_num_rows($b)){
     $email = $c["email"];
     $password = $c["password"];
     $schedule_exists = false;
   }else{
            $post_arr = array(
                'Response' => 'NACK',
                'Message' => 'Invalid MAC! No user was found against this MAC'
            );
            print_r(json_encode($post_arr));
            exit();die();
   }

     // $csount=0;
    $sql = "SELECT * FROM schedule WHERE machine_mac='".$Machine_Mac."'";
    $result = mysqli_query($con, $sql);
    if(mysqli_num_rows($result)) {
        $schedule_exists=true;
        $schedule = $row = mysqli_fetch_array($result);
        $time_condition = $date_condition = false;

        $start_time = $row["start_time"];
        $end_time = $row["end_time"];
        $start_date = $row["start_date"];
        $end_date = $row["end_date"];
        // ============= For TIme
        $time = "2019-12-08";
        require 'time_config.php';
        //$date = date('m/d/Y h:i:s a', time());
        $start_time = date("h:i:s a", strtotime($start_time));
        $end_time = date("h:i:s a", strtotime($end_time));
        $current_time = date('h:i:s a', time());
        $current_date = date('Y-m-d', time());
        //=============  For Date
        $current_date = date('Y-m-d', time());
        //======================== Listing all
//        echo 'Start Time: ' . $start_time . '<br>';
//        echo 'End Time: ' . $end_time . '<br>';
//        echo 'Start Date: ' . $start_date . '<br>';
//        echo 'End Date: ' . $end_date . '<br>';
//        echo 'Current Time: ' . $current_time . '<br>';
//        echo 'Current Date: ' . $current_date . '<br>';
/**/

        if (($start_time < $current_time) && ($end_time > $current_time) ) {
//            echo '<br> TIme Condition Matched!';
            $time_condition = true;
        } else {
            //send mail for an unauthorised request for invalid time
        }
        if (($start_date < $current_date || $start_date == $current_date)
            && ($end_date > $current_date || $end_date == $current_date)) {
//            echo '<br> Date Condition Matched!';
            $date_condition = true;
        }
        else {
            $date_condition = $date_condition = false;
            //send mail for an unauthorised request for invalid date
        }
    }


    //print_r($data);
    //echo $count;


    if($count>0){
//        echo '<br>COunt is zero on line85<br>';
        if($schedule_exists){
//            echo "schedule Exists!";
            $schedule_open_rqst = $schedule["request_send_open"];
            $schedule_close_rqst = $schedule["request_send_close"];

//            if($schedule["schedule_nature"]=="close" || $schedule["schedule_nature"]=="Close"){
//                $action = "Close";
//            }
//            if($schedule["schedule_nature"]=="Open" || $schedule["schedule_nature"]=="open"){
////                $action="Open";
//                $action="Hold";
////                echo "action is in OPEN";
//            }
//                echo "action is in close";
            // if relay is momentary, no close requests will be sent
            if($data["relay"]=="Momentary"){
                $action="Open";
            }
            // if relay is unlatched, no open/hold requests will be sent
            if($data["relay"]=="Unlatch"){
                $action="Close";
            }
            // if relay is none, no commands requests will be sent
            if($data["relay"]=="Latch"){
                $action=$Action;
                $action='Open';
            }


//            if($current_time > $start_time && $current_time < $end_time && !$schedule_open_rqst){
            if($current_time > $start_time && $current_time < $end_time){
                // For Open/Close Schedule
//                echo "currently setting the action to $action";
                $qury="UPDATE user_and_devices SET server_request='$action' WHERE machine_mac='".$Machine_Mac."'";
                $qury1="UPDATE schedule SET request_send_open=1 WHERE machine_mac='".$Machine_Mac."'";
                mysqli_query($con,$qury);
                mysqli_query($con,$qury1);
            }

//            if ($current_time > $end_time && !$schedule_close_rqst){
            if ($current_time > $end_time){
            // set request to CLOSE;
//                echo "currently setting the action to Close(hardcoded)";
            $qury="UPDATE user_and_devices SET server_request='Close' WHERE machine_mac='".$Machine_Mac."'";
            $qury1="UPDATE schedule SET request_send_close=1 WHERE machine_mac='".$Machine_Mac."'";
            mysqli_query($con,$qury);
            mysqli_query($con,$qury1);
            }

            $qury="SELECT * FROM user_and_devices WHERE machine_mac='".$Machine_Mac."'";
            $a =mysqli_query($con,$qury);
            //echo a.'--'.$qury;
            $b = mysqli_fetch_assoc($a);
            $rqst = $b["server_request"];
            //Empty request in database
            $qury1="UPDATE user_and_devices SET server_request='' WHERE machine_mac='".$Machine_Mac."'";
            mysqli_query($con,$qury1);

            $a = $schedule["start_date"].' '.$schedule["start_time"];
            $b = $schedule["end_date"].' '.$schedule["end_time"];
//            echo $b;
//            die();exit();
            $diff = strtotime($b) - strtotime($a);
//            echo $diff;
//            die();exit();
            $alarm = $data["alarm"];
            if($data["alarm"]=="none")
                $alarm = 0;

            if($data["relay"]=="Momentary") {
                echo json_encode(
                    array(
                        'Request' => $rqst, //$data["server_request"], // Change server_rqeust to action for mobile requests
                        'Event' => $schedule["event"],
                        'Pos' => $schedule["positions"],
                        'Exit' => 'ON',   //Dummy
                        'Relay' => $diff,
                        'Buzz' => $data["momentary_time"],
                        'Mobile_MAC' => $data["mobile_mac"],
                        'Machine_MAC' => $data["machine_mac"],
                        'User' => $email,
                        'Password' => $password
                    )
                );
            }else{
                echo json_encode(
                    array(
                        'Request' => $rqst, //$data["server_request"], // Change server_rqeust to action for mobile requests
                        'Event' => $schedule["event"],
                        'Pos' => $schedule["positions"],
                        'Exit' => 'ON',   //Dummy
                        'Relay' => $data["relay"],
                        'Buzz' => $alarm,
                        'Mobile_MAC' => $data["mobile_mac"],
                        'Machine_MAC' => $data["machine_mac"],
                        'User' => $email,
                        'Password' => $password
                    )
                );
            }
        }
        if(!$schedule_exists){

            $alarm = $data["momentary_time"];
            if($data["alarm"]=="none")
                $alarm = 0;

            echo json_encode(
                array(
                    'Request' => $data["server_request"], // Change server_rqeust to action for mobile requests
                    'Event' => 'OFF',
                    'Pos' => 'OFF',
                    'Exit' => 'OFF',   //Dummy
                    'Buzz' => $alarm,
                    'Mobile_MAC' => $data["mobile_mac"],
                    'Machine_MAC' => $data["machine_mac"],
                    'User' => $email,
                    'Password' => $password
                )
            );

        }
    } else{
            $post_arr = array(
                'Response' => 'NACK',
                'Message' => 'No Data returned from Database!'
            );
            print_r(json_encode($post_arr));
    }
    
    // Close connection
    mysqli_close($con);

}else{
            echo json_encode(
                  array(
                      'Response' => 'NACK',
                      'Message' => 'Error Occured While Processing Request'
                  )
                );
}


function success_msg($req, $mobile_mac, $mach_mac){
    echo json_encode(
      array(
          'Response' => 'ACK',
          'Mobile_MAC' => $mobile_mac,
          'Machine_MAC' => $mach_mac
      )
    );
  }


?>